window.onload = function(){
    // arash Rizvi
    /*Navigator: the browser
    document: the html page
    window: the current containing window
    style: the css properties of an element*/

    document.images[0].style.width = '100px';
}